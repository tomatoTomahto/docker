# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""Schema to which the passed configuration should comply"""

SCHEMA_VALIDATION = {
    "definitions": {
        "validation_options": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "enable": {"type": "boolean"},
                "action": {"type": "string", "enum": ["raise", "warn"]},
                "on_missing_suite": {
                    "type": "string",
                    "enum": ["ignore", "ask", "warn", "raise"],
                },
                "suite": {"type": "string"},
                "callbacks": {"type": ["array", "string"], "items": {"type": "string"}},
                "profiler": {
                    "type": "object",
                    "required": ["name"],
                    "additionalProperties": False,
                    "properties": {
                        "name": {"type": "string"},
                        "included_expectations": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "excluded_expectations": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                },
            },
        },
    },
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "custom_expectations": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "pandas": {"type": "array", "items": {"type": "string"}},
                "spark": {"type": "array", "items": {"type": "string"}},
            },
        },
        "validation": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "enable": {"type": "boolean"},
                "default": {"$ref": "#/definitions/validation_options"},
                "config_groups": {
                    "type": "object",
                    "additionalProperties": False,
                    "patternProperties": {
                        "^[a-z0-9-_]+$": {
                            "required": ["filters"],
                            "additionalProperties": False,
                            "properties": {
                                "enable": {"type": "boolean"},
                                "action": {"type": "string", "enum": ["raise", "warn"]},
                                "on_missing_suite": {
                                    "type": "string",
                                    "enum": ["ignore", "ask", "warn", "raise"],
                                },
                                "suite": {"type": "string"},
                                "callbacks": {
                                    "type": ["array", "string"],
                                    "items": {"type": "string"},
                                },
                                "profiler": {
                                    "type": "object",
                                    "required": ["name"],
                                    "additionalProperties": False,
                                    "properties": {
                                        "name": {"type": "string"},
                                        "included_expectations": {
                                            "type": "array",
                                            "items": {"type": "string"},
                                        },
                                        "excluded_expectations": {
                                            "type": "array",
                                            "items": {"type": "string"},
                                        },
                                    },
                                },
                                "filters": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "properties": {
                                        "dataset": {"type": "string"},
                                        "layer": {"type": "string"},
                                    },
                                    "anyOf": [
                                        {"required": ["dataset"]},
                                        {"required": ["layer"]},
                                    ],
                                },
                            },
                        }
                    },
                },
            },
        },
    },
}
