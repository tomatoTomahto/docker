# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.


# pylint: disable=too-many-ancestors, abstract-method
"""Additional pandas expectations for GE"""


from typing import Dict

from great_expectations.dataset import MetaPandasDataset, PandasDataset

from kedro_great_expectations.config import get_custom_expectations
from kedro_great_expectations.expectations.dataset_utils import expect_table_columns


class KedroPandasDataset(*get_custom_expectations("pandas"), PandasDataset):
    """Holds the additional custom expectations for pandas dataframes."""

    _data_asset_type = "KedroPandasDataset"

    @MetaPandasDataset.expectation(["schema", "allow_subset"])
    def expect_table_schema(
        self, schema: Dict[str, str], allow_subset: bool = False,
    ) -> Dict:
        """Check the schema (column names and types) of the data

        Args:
            schema: A dictionary whose keys are the column
                names, and the values are the string representations of the
                column types.
            allow_subset: Whether the specified columns are a subset of all
                dataframe's columns, or whether the df should contain all
                columns.

        Returns:
            A JSON-serializable dictionary (nesting allowed).
        """
        result = expect_table_columns(self.columns, [*schema], allow_subset)
        errors = []
        for col, expected_type in schema.items():
            col_dtype = self[col].dtype.name

            if col_dtype != "object":
                actual = self.expect_column_values_to_be_in_type_list(
                    col, type_list=[expected_type]
                )
                if not actual.success:
                    errors.append(
                        "Column `{}` contains `{}` instead of `{}`".format(
                            col, actual.result["observed_value"], expected_type
                        )
                    )

            elif col_dtype != expected_type:
                errors.append(
                    "Column `{}` contains `{}` instead of `{}`".format(
                        col, str(self[col].dtype), expected_type
                    )
                )
        if errors:
            result["error"] = errors

        return {"success": not errors, "result": {"observed_value": result}}
