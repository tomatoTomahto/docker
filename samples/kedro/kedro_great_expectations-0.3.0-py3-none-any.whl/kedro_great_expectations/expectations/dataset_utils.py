# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""Helper functions for custom ge expectations"""

from typing import Dict, List


def expect_table_columns(
    df_columns: List, column_list: List, allow_subset: bool = False
) -> Dict:
    """Helper function used for creating custom expectations. Check if the given columns are exactly equal or a subset
     of the expected columns.

    Args:
        df_columns: The actual dataframe column list.
        column_list: The expected columns.
        allow_subset: Whether ``columns`` is a subset of ``dataframe columns`` or equal.

    Returns:
        On success returns a dictionary, empty if the expected column list is the actual list,
        or with missing_columns for subset columns.

    Raises:
        ValueError: When unexpected columns are found.
    """

    result = {}

    only_in_df = set(df_columns) - set(column_list)
    only_in_val = set(column_list) - set(df_columns)

    if only_in_val:
        raise ValueError("Unexpected columns: {}".format(", ".join(only_in_val)))

    if allow_subset and only_in_df:
        result["missing_columns"] = ", ".join(only_in_df)

    elif only_in_df:
        raise ValueError("Missing columns: {}".format(",".join(only_in_df)))

    return result
