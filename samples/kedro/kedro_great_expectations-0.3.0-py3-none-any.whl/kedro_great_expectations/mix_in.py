# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""
Add this mix in to your KedroProjectContext to easily enable validation
"""

# pylint: disable=unused-argument
from typing import Any, Dict, Union

from kedro.config import MissingConfigException
from kedro.io import DataCatalog
from kedro.io.core import generate_timestamp

from kedro_great_expectations.config import KedroGEConfig
from kedro_great_expectations.default_config import DEFAULT_CONFIG_KEY
from kedro_great_expectations.transformer import ValidationTransformer


class GreatExpectationsMixin:
    """A KedroContext mix-in which integrates great-expectations with kedro"""

    def __init__(
        self,
        *args,
        ge_config_key: str = None,
        validation_callback_kwargs: Dict[str, Any] = None,
        **kwargs
    ):
        super().__init__(*args, **kwargs)
        self._ge_run_id = None
        self._validation_transformer = None
        self._config_key = (
            ge_config_key or getattr(self, "ge_config_key", None) or DEFAULT_CONFIG_KEY
        )
        self._ge_config = None
        self.validation_callback_kwargs = validation_callback_kwargs or getattr(
            self, "validation_callback_kwargs", None
        )

    def _get_save_version(self, *args, **kwargs) -> str:
        try:
            return super()._get_save_version(*args, **kwargs)
        except AttributeError:
            return generate_timestamp()

    def _get_run_id(self, *args, **kwargs) -> Union[None, str]:
        """A hook for generating a unique identifier for a
        run / journal record, defaults to None.
        If None, `save_version` will be used instead.
        """
        if not self._ge_run_id:
            self._ge_run_id = self._get_save_version()
        return self._ge_run_id

    @property
    def ge_config(self) -> KedroGEConfig:
        """The great_expectations config dictionary for KedroGEConfig"""
        if not self._ge_config:
            try:
                self._ge_config = KedroGEConfig(
                    self.config_loader.get(self._config_key)
                )
            except MissingConfigException:
                raise MissingConfigException(
                    "Configuration for the great_expectations plugin with key `{}` was not found.\n"
                    "Specify the right key using `ProjectContext.ge_config_key`, or run `kedro "
                    "ge init` to initialise the plugin in this project.".format(
                        self._config_key
                    )
                )
        return self._ge_config

    def _create_catalog(self, *args, **kwargs) -> DataCatalog:
        catalog = super()._create_catalog(*args, **kwargs)
        self._validation_transformer = ValidationTransformer(
            config=self.ge_config,
            run_id=self._get_run_id(),
            layers=getattr(
                catalog, "layers", {}
            ),  # backwards compatibility for kedro<0.16
            validation_callback_kwargs=self.validation_callback_kwargs,
        )
        catalog.add_transformer(self._validation_transformer)
        return catalog
