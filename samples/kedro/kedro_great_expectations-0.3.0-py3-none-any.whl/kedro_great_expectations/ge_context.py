# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""
Wrappers for functionality provided by great expectations, this module should not know about Kedro
"""
from datetime import datetime
from typing import Any, Dict, Tuple, Type

import great_expectations.exceptions as ge_exceptions
from great_expectations import DataContext
from great_expectations.core import ExpectationSuite, ExpectationSuiteValidationResult
from great_expectations.profile.base import DatasetProfiler

from kedro_great_expectations.extended_profiler import ExtendedProfiler

GREAT_EXPECTATIONS_PATH = "great_expectations"

KEDRO_PANDAS_DATASOURCE = "kedro_pandas_datasource"
KEDRO_SPARK_DATASOURCE = "kedro_spark_datasource"
DATASOURCES = {
    KEDRO_PANDAS_DATASOURCE: {
        "name": KEDRO_PANDAS_DATASOURCE,
        "class_name": "PandasDatasource",
        "data_asset_type": {
            "class_name": "KedroPandasDataset",
            "module_name": "kedro_great_expectations.expectations.pandas_expectations",
        },
    },
    KEDRO_SPARK_DATASOURCE: {
        "name": KEDRO_SPARK_DATASOURCE,
        "class_name": "SparkDFDatasource",
        "data_asset_type": {
            "class_name": "KedroSparkDataset",
            "module_name": "kedro_great_expectations.expectations.pyspark_expectations",
        },
    },
}


class UnsupportedDatasetError(Exception):
    """Error raised when trying to validate an unsupported type"""


def get_ge_context(great_expectations_path: str = None) -> DataContext:
    """The Great Expectations context instance.
    Args:
        great_expectations_path: The root folder of great_expectations' configuration.

    Returns:
        The great_expectations DataContext
    """
    return DataContext(great_expectations_path)


def get_batch_kwargs(
    data: Any, ds_name: str, ge_context: DataContext = None
) -> Dict[str, Any]:
    """Classifies a dataset as either a Pandas or Spark dataset
    using the module names of the underlying dataframe itself,
    and returns the appropriate GE batch_kwargs

    Args:
        data: The dataframe/data itself.
        ds_name: The dataset name as specified in the catalog.
        ge_context: The great_expectations DataContext to use

    Raises:
        UnsupportedDatasetError: If the dataset cannot be classified
            as either a Pandas or Spark DataFrame.

    Returns:
        The kwargs required either by a `KEDRO_PANDAS_DATASOURCE`
        or a `KEDRO_SPARK_DATASOURCE`.
    """
    ge_context = ge_context or get_ge_context()
    typ = type(data).__name__
    module = getattr(data, "__module__", "-")
    if module == "pandas.core.frame":
        datasource = KEDRO_PANDAS_DATASOURCE
    elif module == "pyspark.sql.dataframe":
        datasource = KEDRO_SPARK_DATASOURCE
    else:
        raise UnsupportedDatasetError(
            "Dataset {} of type {} from module {} is not supported. Currently, "
            "only pandas and pyspark datasets are allowed.".format(ds_name, typ, module)
        )

    if datasource not in ge_context.datasources:
        ge_context.add_datasource(**DATASOURCES[datasource])

    return {"dataset": data, "datasource": datasource}


def has_suite(ds_name: str, ge_context: DataContext = None) -> bool:
    """Check whether the dataset specified by name has a non-empty
    expectation suite. Currently assumes a dataset has only one
    expectation suite with the same name.

    Args:
        ds_name: The name of the kedro datasets as specified in the catalog.
        ge_context: The great expectations data context to use, otherwise obtain the default one
    Returns:
        True if the dataset has a corresponding non-empty expectation suite.
    """
    ge_context = ge_context or get_ge_context()
    try:
        suite = ge_context.get_expectation_suite(ds_name)
    except ge_exceptions.DataContextError:
        return False
    return bool(suite.expectations)


def validate(
    ds_name: str,
    data: Any,
    suite_name: str = None,
    run_id: str = None,
    ge_context: DataContext = None,
):
    """Validate a dataset"""
    suite_name = suite_name or ds_name
    ge_context = ge_context or get_ge_context()
    batch_kwargs = get_batch_kwargs(data, ds_name, ge_context)
    batch = ge_context.get_batch(
        batch_kwargs=batch_kwargs, expectation_suite_name=suite_name
    )

    run_id = run_id or datetime.utcnow().strftime("%Y%m%dT%H%M%S.%fZ-kedro-ge-validate")
    return ge_context.run_validation_operator(
        "action_list_operator", assets_to_validate=[batch], run_id=run_id
    )


def generate(
    ds_name: str,
    data: Any,
    empty=False,
    profiler: Type[DatasetProfiler] = ExtendedProfiler,
    suite_name: str = None,
    run_id: str = None,
    ge_context: DataContext = None,
    overwrite_existing: bool = False,
) -> ExpectationSuite:
    """Generate an expectation suite for a dataset."""
    suite_name = suite_name or ds_name
    ge_context = ge_context or get_ge_context()
    suite = ge_context.create_expectation_suite(
        expectation_suite_name=suite_name, overwrite_existing=overwrite_existing
    )

    if empty:
        return suite

    batch_kwargs = get_batch_kwargs(data, ds_name, ge_context)
    batch = ge_context.get_batch(
        batch_kwargs=batch_kwargs, expectation_suite_name=suite_name,
    )
    run_id = run_id or datetime.utcnow().strftime("%Y%m%dT%H%M%S.%fZ-kedro-ge-generate")
    suite, _ = profiler.profile(batch, run_id=run_id)
    ge_context.save_expectation_suite(suite)
    return suite


def profile(
    ds_name: str,
    data: Any,
    profiler: Type[DatasetProfiler] = ExtendedProfiler,
    ge_context: DataContext = None,
    profiler_config: Dict = None,
) -> Tuple[ExpectationSuite, ExpectationSuiteValidationResult]:
    """Profile a dataset"""
    ge_context = ge_context or get_ge_context()
    batch_kwargs = get_batch_kwargs(data, ds_name, ge_context)
    result = ge_context.profile_data_asset(
        batch_kwargs["datasource"],
        batch_kwargs=batch_kwargs,
        expectation_suite_name="{}_profile".format(ds_name),
        profiler=profiler,
        run_id="profiling",
        profiler_configuration=profiler_config,
    )

    suite, result = result["results"][0]
    return suite, result
