# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""
kedro_great_expectations
A kedro plugin for data validation using great_expectations
"""

__version__ = "0.3.0"


from kedro_great_expectations.extended_profiler import ExtendedProfiler  # noqa
from kedro_great_expectations.mix_in import GreatExpectationsMixin  # noqa
