# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""The central config module for the Kedro GE plugin"""
import logging
import re
from collections import defaultdict
from copy import deepcopy
from functools import reduce
from typing import Any, Dict, List

import click
import kedro
import semver
from jsonschema import validate
from kedro.config import MissingConfigException
from kedro.utils import load_obj

from kedro_great_expectations.config_schema import SCHEMA_VALIDATION
from kedro_great_expectations.default_config import DEFAULT_CONFIG_KEY

LOGGER = logging.getLogger(__name__)

KEDRO_VERSION = semver.VersionInfo.parse(kedro.__version__)

if KEDRO_VERSION.match(">=0.16.0"):
    from kedro.framework.context import KedroContext
else:
    from kedro.context import KedroContext


_MERGE_STRATEGY = {
    "enable": {False: 0, True: 1, "_how": "rank"},
    "action": {"warn": 0, "raise": 1, "_how": "rank"},
    "on_missing_suite": {"ignore": 0, "ask": 2, "warn": 2, "raise": 3, "_how": "rank"},
    "group_names": {"_how": "concat"},
    "callbacks": {"_how": "union"},
    "profiler": {"_how": "use_default"},
}

DEFAULT_PROFILER = "kedro_great_expectations.ExtendedProfiler"

_DEFAULTS = {
    "enable": True,
    "action": "raise",
    "on_missing_suite": "ignore",
    "callbacks": [],
    "suite": "",
    "profiler": {"name": DEFAULT_PROFILER},
}

_GROUP_DEFAULTS = {**_DEFAULTS, "filters": {"dataset": "", "layer": ""}}

_DEFAULT_CONFIG = {
    "validation": {"enable": True, "default": _DEFAULTS, "config_groups": {}},
}

_EMPTY = object()
_CUSTOM_EXPECTATIONS = {"pandas": _EMPTY, "spark": _EMPTY}


class KedroGEConfigError(Exception):
    """Error raised when unsupported configuration is provided"""


def get_custom_expectations(dataset_type: str) -> List[Any]:
    """Get the list of custom expectations for a specified dataset type.

    Args:
        dataset_type: The type of dataset to fetch custom expectations for.

    Raises:
        KeyError: If there is no key corresponding to the specified dataset_type.

    Returns:
        List of custom expectations for the dataset type.
    """
    global _CUSTOM_EXPECTATIONS  # pylint: disable=global-statement
    custom_exps = _CUSTOM_EXPECTATIONS.get(dataset_type)

    if custom_exps is None:
        raise KeyError(
            "Custom expectations for {} couldn't be found. "
            "Current supported types are: {}".format(
                dataset_type, ", ".join(_CUSTOM_EXPECTATIONS.keys())
            )
        )
    if _CUSTOM_EXPECTATIONS[dataset_type] is _EMPTY:
        LOGGER.warning(
            "You have not created a `KedroGEConfig` before "
            "importing `kedro_great_expectations.expectations.Kedro*Dataset`. "
            "No custom expectations defined in kedro-great-expectations config "
            "file have been loaded."
        )
        return []
    return _CUSTOM_EXPECTATIONS[dataset_type]


class KedroGEConfig:
    """Responsible for loading the configuration for the plugin."""

    # whether :class:`kedro_great_expectations.transformer.ValidationTransformer` should
    # validate datasets or not
    TRANSFORMER_ENABLED = True

    def __init__(self, config: Dict = None):
        """Loads and holds the config for the plugin.

        Args:
            config: A config dictionary following the schema documented in the user guide.
        """
        global _CUSTOM_EXPECTATIONS  # pylint: disable=global-statement
        if config:
            updated_config = _add_defaults_if_missing(deepcopy(_DEFAULT_CONFIG), config)
            self.config = _validate_config_schema(updated_config)
        else:
            self.config = _DEFAULT_CONFIG
        _CUSTOM_EXPECTATIONS = _get_custom_expectations(
            self.config.get("custom_expectations") or {}
        )
        _CUSTOM_EXPECTATIONS.setdefault("pandas", [])
        _CUSTOM_EXPECTATIONS.setdefault("spark", [])
        self._custom_expectations = None

    @classmethod
    def for_interactive_mode(
        cls, kedro_context: KedroContext, disable_transformer: bool = True
    ) -> "KedroGEConfig":
        """Used internally - not a user facing function.

        Indicates that the user is running validation in 'offline' mode, i.e from the
        terminal/jupyter notebook, and not during a pipeline run.

        Disables the ValidationTransformers, and either obtains the KedroGEConfig from the
        GreatExpectationsMixin, or creates a new one. We need the KedroGEConfig in order to
        load custom expectations defined in `kedro_ge.yml`.

        Args:
            kedro_context: The kedro project context
            disable_transformer: Whether to disable the ValidationTransformer that might
                be attached to the context's catalog

        Returns:
            A KedroGEConfig instance, either obtained from the GreatExpectationsMixin, or
            a freshly created one from the kedro_ge.yml file (if exists), or one containing the
            default configuration
        """
        cls.TRANSFORMER_ENABLED = not disable_transformer

        config = getattr(kedro_context, "ge_config", None)
        if config:
            return config

        ge_config_key = getattr(kedro_context, "ge_config_key", DEFAULT_CONFIG_KEY)
        try:
            config_dict = kedro_context.config_loader.get(ge_config_key)
        except MissingConfigException:
            config_dict = None
            LOGGER.warning(
                "Configuration for the great_expectations plugin with key `%s` was not "
                "found.\nSpecify the right key using `ProjectContext.ge_config_key`, "
                "or run `kedro ge init` to initialise the plugin in this project.\n"
                "No custom expectations loaded.",
                ge_config_key,
            )
        return KedroGEConfig(config_dict)

    @property
    def custom_expectations(self):
        """A dictionary with pandas and spark keys whose values are lists of expectation classes."""
        if not self._custom_expectations:
            custom_exps = self.config.get("custom_expectations") or {}
            self._custom_expectations = _get_custom_expectations(custom_exps)
        return self._custom_expectations

    @property
    def validation_config(self):
        """Validation config"""
        return self.config.get("validation", {})

    def merged_configs_for(
        self, dataset_name: str, layer_name: str = ""
    ) -> Dict[str, Any]:
        """Get the merged validation config matching the specified dataset and layer name.
        This is of the form:
        {
            "suite_name": {
                "enable": True / False
                "on_missing_suite": raise / warn / ask / ignore(default) (in precedence order)
                "action": raise (default) / warn  (in precedence order)
                "callbacks": set[str] of callback paths (e.g {"my_module.my_callback"})
                "group_names": comma separated list of configs which matched
            }
        }

        Configs which have {"enabled": False} contain only the "enable" and "group_names" keys.

        Args:
            dataset_name: The dataset name.
            layer_name: (Optional) The name of the dataset layer.

        Returns:
            A merged validation config
        """

        def _log_duplicate_profilers(suite_name, config):
            if not all(
                config[i]["profiler"] == config[i - 1]["profiler"]
                for i in range(1, len(config))
            ):
                LOGGER.warning(
                    click.style(
                        "Multiple configuration groups with different profilers match suite: %s. "
                        "These are the matching profilers %s found in groups %s. "
                        "Due to the conflict, the default ExtendedProfiler will be used.",
                        fg="red",
                    ),
                    suite_name,
                    [i["profiler"] for i in config],
                    [i["group_names"] for i in config],
                )

        def _merge(left, right):
            merged = {}
            for key in right:
                if _MERGE_STRATEGY[key]["_how"] == "use_default":
                    if left[key] != right[key]:
                        merged[key] = _DEFAULTS[key]
                    else:
                        merged[key] = right[key]
                elif _MERGE_STRATEGY[key]["_how"] == "concat":
                    merged["group_names"] = "{},{}".format(left[key], right[key])
                elif _MERGE_STRATEGY[key]["_how"] == "union":
                    merged[key] = left.get(key, set()).union(right[key])
                elif _MERGE_STRATEGY[key][right[key]] >= _MERGE_STRATEGY[key].get(
                    left.get(key, "_"), 0
                ):
                    merged[key] = right[key]
                else:
                    merged[key] = left[key]
            return merged

        suite_configs = defaultdict(list)

        for config_name, config in self._validation_configs_for(
            dataset_name, layer_name
        ).items():
            config.pop("filters")
            suite_name = config.pop("suite") or dataset_name
            if not config["enable"]:
                suite_configs[suite_name].append(
                    {
                        "enable": False,
                        "group_names": config_name,
                        "profiler": {"name": DEFAULT_PROFILER},
                    }
                )
            else:
                config["group_names"] = config_name
                suite_configs[suite_name].append(config)

        for suite_name, config in suite_configs.items():
            _log_duplicate_profilers(suite_name, config)
            suite_configs[suite_name] = reduce(_merge, suite_configs[suite_name])

        return suite_configs

    def _validation_configs_for(
        self, dataset_name: str, layer_name: str = ""
    ) -> Dict[str, Any]:
        """Get the validation configs matching the specified dataset and layer name.

        Args:
            dataset_name: The dataset name.
            layer_name: (Optional) The name of the dataset layer.

        Returns:
            A dict of config settings that match the configuration
            group specified by the dataset and layer name
        """
        default_config = self.validation_config.get("default") or _DEFAULTS
        config_groups = self.validation_config.get("config_groups") or {}
        config_groups = _filter_config(config_groups, dataset_name, layer_name)

        if default_config and not config_groups:
            config_groups = {"default": default_config}

        for key, group in config_groups.items():
            group = _add_defaults_if_missing(deepcopy(_GROUP_DEFAULTS), group)
            callbacks = (
                [group["callbacks"]]
                if isinstance(group["callbacks"], str)
                else group["callbacks"]
            )
            for idx, callback in enumerate(callbacks):
                callbacks[idx] = load_obj(callback)
            group["callbacks"] = set(callbacks)
            config_groups[key] = group
        return config_groups


def _validate_config_schema(config: Dict):
    if "profiling" in config:
        # pylint: disable=line-too-long
        raise KedroGEConfigError(
            click.style(
                "Old configuration schema detected. "
                "Please migrate to the new configuration schema following "
                "the steps in https://github.com/quantumblack/kedro-great-expectations/blob/master/RELEASE.md#config-migration-to-v030",
                fg="red",
            )
        )
    validate(config, schema=SCHEMA_VALIDATION)
    return config


def _filter_config(
    config_groups: Dict[str, Dict[str, Any]], dataset_name: str, layer_name: str
) -> Dict[str, Dict[str, Any]]:
    filtered_groups = {}
    for name, group in config_groups.items():
        filters = group["filters"]
        config_dataset_name = filters.get("dataset", ".*")
        config_layer_name = filters.get("layer", ".*")

        matched_dataset_name = re.match(config_dataset_name, dataset_name)
        matched_layer_name = re.match(config_layer_name, layer_name)

        if matched_dataset_name and matched_layer_name:
            filtered_groups[name] = group

    return filtered_groups


def _add_defaults_if_missing(default, group):
    for key in group:
        if isinstance(default.get(key), dict) and isinstance(group.get(key), dict):
            _add_defaults_if_missing(default[key], group[key])
        else:
            default[key] = group[key]
    return default


def _get_custom_expectations(
    custom_expectations: Dict[str, List[str]]
) -> Dict[str, List[Any]]:
    """Get all the custom expectation classes, keyed under pandas and spark separately.

    Args:
        custom_expectations: A dictionary keyed by type,
            whose values are lists of fully qualified class paths.

    Returns:
        A mapping between expectation types and lists of expectation classes.
    """
    return {
        exp_type: [load_obj(exp_class) for exp_class in exp_classes]
        for exp_type, exp_classes in custom_expectations.items()
    }
