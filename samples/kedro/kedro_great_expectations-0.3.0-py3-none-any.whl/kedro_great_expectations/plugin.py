# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""
Kedro plugin for integration with Great Expectations
(https://greatexpectations.io)
"""
import platform
import subprocess
import sys
import textwrap
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import click
from click import ClickException
from great_expectations import __version__ as ge_version
from great_expectations.data_context.types.resource_identifiers import (
    ExpectationSuiteIdentifier,
)
from kedro import __version__ as kedro_version
from log_symbols import LogSymbols
from tabulate import tabulate

from kedro_great_expectations import __version__ as plugin_version
from kedro_great_expectations import ge_context
from kedro_great_expectations.default_config import DEFAULT_CONFIG, DEFAULT_CONFIG_PATH
from kedro_great_expectations.ge_context import has_suite
from kedro_great_expectations.kedro_ge_context import KedroGEContext

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])
VERSION_MESSAGE = (
    "Kedro-Great_Expectations: {}, Kedro: {}, Great Expectations: {}, "
    "Python: {}, {}: {}".format(
        plugin_version,
        kedro_version,
        ge_version,
        platform.python_version(),
        platform.system(),
        platform.release(),
    )
)

OVERWRITE_GEN_ARG_HELP = (
    "Overwrite the existing expectation suites with auto generated expectations"
)
EMPTY_GEN_ARG_HELP = "Don't autogenerate expectations"
ENV_ARG_HELP = "What kedro environment to use when looking up datasets"
FILTER_ARG_HELP = "Glob pattern to filter dataset names with"
TYPE_ARG_HELP = "Filter dataset types using their str name"
ONLY_SUITES_ARG_HELP = "Only list datasets that have non-empty expectation suites"
VERBOSE_ARG_HELP = (
    "Verbose output for validation which shows which expectations have passed and failed, "
    "specifying the column where relevant."
)
GROUP_ARG_HELP = "Group all validations under a single run_id"
SUITE_ARG_HELP = "Validate your data against specific suites."

ENV_OPTION = click.option(
    "--env",
    "-e",
    type=str,
    default=None,
    multiple=False,
    envvar="KEDRO_ENV",
    help=ENV_ARG_HELP,
)

FILTER_OPTION = click.option(
    "--filter",
    "-f",
    "filter_",
    type=str,
    default=None,
    multiple=None,
    help=FILTER_ARG_HELP,
)

TYPE_OPTION = click.option(
    "--type", "-t", "types", type=str, multiple=True, help=TYPE_ARG_HELP
)

DATASET_ARGUMENT = click.argument("datasets", nargs=-1)


@click.group(name="Great_Expectations")
def commands():
    """Kedro plugin for interacting with Great Expectations"""


@commands.group(name="ge", context_settings=CONTEXT_SETTINGS)
@click.version_option(
    plugin_version,
    "-V",
    "--version",
    message=VERSION_MESSAGE,
    help="Show version and exit",
)
def ge_group():
    """Kedro plugin for interacting with Great Expectations"""


@ge_group.command(name="init")
@click.option(
    "--config",
    "-c",
    "config_path",
    type=click.Path(exists=False, dir_okay=False, writable=True),
    default=DEFAULT_CONFIG_PATH,
    multiple=False,
    help="Filepath to dump default configuration file",
)
def ge_init(config_path):
    """Initialise a kedro great expectations project"""
    context = KedroGEContext()
    context.initialise_ge()
    config_path = _normalise_config_path(config_path, context)
    _dump_default_config(config_path)
    click.secho("Great Expectations initialised in your kedro project", fg="green")


@ge_group.command(name="list")
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
@click.option(
    "--only-suites", "-o", is_flag=True, default=False, help=ONLY_SUITES_ARG_HELP
)
def ge_list(filter_, env, types, only_suites):
    """List all kedro datasets. Those that have
    non-empty expectation suites are in cyan.
    """
    context = KedroGEContext(env=env, dataset_filter=filter_, dataset_types=types)
    _ge_context = ge_context.get_ge_context()
    validations = _ge_context.validations_store.list_keys()
    empty_value = "-"
    missing_color = "yellow"
    exists_color = "cyan"

    def _get_legend():
        padding = 2
        return "\n".join(
            [
                "\nLegend:",
                f"{' ' * padding}{click.style('existing suite', fg=exists_color)}",
                f"{' ' * padding}{click.style('missing suite', fg=missing_color)}",
            ]
        )

    def _get_last_validation_status(suite_name: str) -> str:
        suite_runs = [
            i.run_id
            for i in validations
            if suite_name == i.expectation_suite_identifier.expectation_suite_name
        ]
        if not suite_runs:
            return empty_value
        last_run_id = sorted(suite_runs)[-1]
        last_validation_status = _ge_context.get_validation_result(
            suite_name, run_id=last_run_id
        ).success
        return "✅" if last_validation_status else "❌"

    def _get_icon(module_type: Optional[str]) -> str:
        if module_type == "pandas":
            return "🐼"
        if module_type == "spark":
            return "⚡"
        return "🗄"

    def _format_dataset(dataset: Dict[str, str]) -> List[List[str]]:
        result = []
        ds_name = dataset["ds_name"]
        icon = _get_icon(dataset["module_type"])
        ds_type = f"{icon} {dataset['ds_type']}"
        config = context.kedro_ge_config.merged_configs_for(ds_name)
        for suite in config:
            suite_exists = ge_context.has_suite(suite)
            if only_suites and not suite_exists:
                continue

            config_group_name = config[suite]["group_names"]
            suite_name = click.style(
                config.get("suite", suite),
                fg=exists_color if suite_exists else missing_color,
            )
            last_validation_status = empty_value
            if suite_exists:
                last_validation_status = _get_last_validation_status(suite_name)

            result.append(
                [
                    str(dataset["index"]),
                    ds_name,
                    ds_type,
                    suite_name,
                    config_group_name,
                    last_validation_status,
                ]
            )
        return result

    table = []
    for dataset in context.kedro_datasets.datasets:
        table += _format_dataset(dataset)

    headers = ["Id", "Name", "Type", "Suite", "Config group", "Last val"]
    click.echo(tabulate(table, headers, tablefmt="presto"))
    click.echo(_get_legend())


@ge_group.command(name="profile")
@DATASET_ARGUMENT
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
def ge_profile(datasets, filter_, env, types):
    """Profile your kedro datasets using great expectations"""
    context = KedroGEContext(
        env=env, dataset_filter=filter_, dataset_types=types, locate_args=datasets
    )
    exit_code = 0
    for ds_name in context.ds_names:
        result = context.profile(ds_name)
        if not result.success:
            click.echo(
                _format_exception("profiling", ds_name, ds_name, result.exception)
            )
            exit_code = 1
            continue

        _echo_symbol(
            LogSymbols.SUCCESS.value, "Profiled dataset {} succesfully".format(ds_name)
        )

    sys.exit(exit_code)


@ge_group.command(name="validate")
@DATASET_ARGUMENT
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
@click.option("--verbose", "-v", is_flag=True, default=False, help=VERBOSE_ARG_HELP)
@click.option("--group", "-g", is_flag=True, default=False, help=GROUP_ARG_HELP)
@click.option(
    "--suite", "-s", "suites", default=None, multiple=True, help=SUITE_ARG_HELP
)
def ge_validate(datasets, filter_, env, types, verbose, group, suites):
    """Validate your kedro datasets against existing expectation suites"""
    context = KedroGEContext(
        env=env, dataset_filter=filter_, dataset_types=types, locate_args=datasets
    )
    run_id = datetime.utcnow().strftime("%Y%m%dT%H%M%S.%fZ") if group else None

    exit_code = 0
    for ds in context.ds_names:
        ds_suites = suites or [ds]

        for suite in ds_suites:
            if not has_suite(suite, context.ge_context):
                message = "Skipping validation of {}: expectation suite {} not found or empty".format(
                    click.style(ds, fg="cyan"), suite
                )
                _echo_symbol(LogSymbols.INFO.value, message)
                continue

            result = context.validate(ds_name=ds, suite=suite, run_id=run_id)

            if not result.success or not result.result["success"]:
                exit_code = 1

            if not result.success:
                click.echo(_format_exception("validation", ds, suite, result.exception))
                continue

            messages = _parse_validation_results(ds, result.result, verbose, suite)

            for symbol, message, indent in messages:
                _echo_symbol(symbol, message, indent=indent)

    sys.exit(exit_code)


@ge_group.command(name="generate")
@DATASET_ARGUMENT
@FILTER_OPTION
@ENV_OPTION
@TYPE_OPTION
@click.option("--empty", is_flag=True, default=False, help=EMPTY_GEN_ARG_HELP)
@click.option("--overwrite", is_flag=True, default=False, help=OVERWRITE_GEN_ARG_HELP)
def ge_generate(datasets, filter_, env, types, empty, overwrite):
    """Generate expectation suites for your kedro datasets"""
    context = KedroGEContext(
        env=env, dataset_filter=filter_, dataset_types=types, locate_args=datasets
    )

    ds_names_with_suites = context.ds_names_with_suites
    ds_names_without_suites = context.ds_names_without_suites
    if overwrite:
        ds_names_without_suites |= ds_names_with_suites
        ds_names_with_suites = set()

    for ds in ds_names_with_suites:
        _echo_symbol(
            LogSymbols.INFO.value, "Expectation suite {} already exists".format(ds)
        )
    exit_code = 0
    for ds in ds_names_without_suites:
        message = "Generated prefilled expectation suite {}".format(ds)
        if empty:
            message = "Generated empty expectation suite {}".format(ds)

        # overwrite_existing is always True because ds can be one of:
        #   - data sets without expectation suites -> create
        #   - data sets with empty expectation suites -> overwrite
        #   - data sets with non empty expectations suites -> overwrite
        #       when overwrite flag is True
        result = context.generate(ds_name=ds, empty=empty, overwrite_existing=True)
        if not result.success:
            click.echo(_format_exception("generation", ds, ds, result.exception))
            exit_code = 1
            continue

        _echo_symbol(LogSymbols.SUCCESS.value, message)

    if not overwrite and ds_names_with_suites:
        message = "\n({}) You can pass the '--overwrite' flag to 'kedro ge generate' to {}".format(
            LogSymbols.INFO.value, OVERWRITE_GEN_ARG_HELP.lower()
        )
        click.secho(message)

    sys.exit(exit_code)


@ge_group.command(
    name="edit", context_settings=dict(ignore_unknown_options=True,),
)
@ENV_OPTION
@click.argument("name")
@click.argument("jupyter_options", nargs=-1, type=click.UNPROCESSED)
def ge_edit(env, name, jupyter_options):
    """Edit expectation suite for a kedro dataset.

    Pass all optional arguments here that kedro jupyter notebook accepts.
    Run `jupyter notebook --help` to view the available options.
"""
    if name.startswith("-"):
        raise ClickException("Please first specify the dataset, only after the options")
    env_option = ["--env", env] if env else []
    context = KedroGEContext(env=env)
    notebook_path = context.edit(name)
    subprocess.call(
        ["kedro", "jupyter", "notebook", *env_option, *jupyter_options, notebook_path]
    )


@ge_group.command(name="docs")
def ge_open():
    """Open the data docs"""
    context = KedroGEContext()
    context.ge_context.build_data_docs()
    context.ge_context.open_data_docs()


def _echo_symbol(symbol, message, indent=None, **kwargs):
    message = "[{}] {}".format(symbol, message)
    if indent:
        message = textwrap.indent(message, " " * indent)

    click.secho(message, **kwargs)


def _parse_validation_results(
    ds_name: str, results: Dict[str, Any], verbose: bool, suite_name: str
):
    messages = []
    colored_suite_name = click.style(suite_name, fg="cyan")
    if results["success"]:
        ds = click.style(ds_name, fg="green")
        message = "Expectation suite {} for {} passed".format(colored_suite_name, ds)
        symbol = LogSymbols.SUCCESS.value
    else:
        ds = click.style(ds_name, fg="red")
        message = "Expectation suite {} for {} failed".format(colored_suite_name, ds)
        symbol = LogSymbols.ERROR.value

    messages.append((symbol, message, None))

    if verbose:
        suite_id = ExpectationSuiteIdentifier(suite_name)
        validations = results["details"][suite_id]["validation_result"]["results"]
        for validation in validations:
            symbol, message = _verbose_message(validation)
            messages.append((symbol, message, 4))

    return messages


def _verbose_message(validation):
    rule = validation.expectation_config.expectation_type
    rule = click.style(rule, fg="yellow")
    details = validation.expectation_config.kwargs
    if validation.success:
        message = "Rule {} passed".format(rule)
        symbol = LogSymbols.SUCCESS.value
    else:
        message = "Rule {} failed".format(rule)
        symbol = LogSymbols.ERROR.value

    column = details.get("column")
    if column:
        column = click.style(column, fg="blue")
        message = "{} for column {}".format(message, column)
    return symbol, message


def _normalise_config_path(config_path, context):
    while True:
        config_path = Path(config_path)
        if not config_path.is_absolute():
            config_path = context.project_root / config_path
        if not config_path.exists():
            return config_path
        click.secho("{} already exists.".format(config_path), fg="red")
        config_path = click.prompt(
            "Configuration file path?",
            default=DEFAULT_CONFIG_PATH,
            type=click.Path(exists=False, dir_okay=False),
        )


def _dump_default_config(filepath):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    filepath.write_text(DEFAULT_CONFIG)


def _format_exception(
    command_name: str, ds_name: str, suite: str, exc: Exception
) -> str:
    """Format exceptions"""
    # pylint: disable=line-too-long
    return f"[{LogSymbols.ERROR.value}] {command_name.capitalize()} using suite {click.style(suite, fg='cyan')} for dataset {click.style(ds_name, fg='red')} failed. {exc.__class__.__name__}: {exc}"
