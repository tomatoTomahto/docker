# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""Profiler based on GE's BasicSuiteBuilderProfiler"""
import logging
from typing import Any, Dict, List

from great_expectations.dataset.util import build_continuous_partition_object
from great_expectations.exceptions import ProfilerError
from great_expectations.profile.base import ProfilerCardinality, ProfilerDataType
from great_expectations.profile.basic_suite_builder_profiler import (
    BasicSuiteBuilderProfiler,
    _check_that_expectations_are_available,
    _remove_column_expectations,
    _remove_table_expectations,
)

LOGGER = logging.getLogger(__name__)


class ExtendedProfiler(BasicSuiteBuilderProfiler):
    """ Profiler based on GE's BasicSuiteBuilderProfiler

       In addition to the expectations created by the BasicSuiteBuilderProfiler, this profiler
       adds some more expectations, which results in the list of expectations below:

       This profiler does the following analyses and creates the corresponding expectations:
       - Table row count → expect_table_row_count_to_be_between
       - Table column count → expect_table_column_count_to_equal
       - Table column match → expect_table_columns_to_match_ordered_list
       - Check for null values in column → expect_column_values_to_not_be_null
       - Check schema for the table → expect_table_schema


       Numeric profiling
       - Column min value → expect_column_min_to_be_between
       - Column max value → expect_column_max_to_be_between
       - Column mean value → expect_column_mean_to_be_between
       - Column median value → expect_column_median_to_be_between
       - Column quantile values → expect_column_quantile_values_to_be_between
       - Column stdev value → expect_column_stdev_to_be_between
       - Column sum → expect_column_sum_to_be_between
       - Kullback-Leibler divergence → expect_column_kl_divergence_to_be_less_than
       - Column uniqueness → expect_column_values_to_be_unique


        String profiling
       - Check string lengths → expect_column_value_lengths_to_be_between
       - Column uniqueness → expect_column_values_to_be_unique


        Datetime profiling
       - Column min datetime → expect_column_min_to_be_between
       - Column max datetime → expect_column_max_to_be_between
       - If both min and max available the above expectations are replaced with expect_column_values_to_be_between


        Low cardinality columns
       - Distinct column values → expect_column_distinct_values_to_be_in_set
       - Kullback-Leibler divergence → expect_column_kl_divergence_to_be_less_than
       """

    @classmethod
    def _build_table_schema_expectations(cls, dataset):
        schema = {}

        for col in dataset.get_table_columns():
            schema[col] = dataset.expect_column_values_to_be_in_type_list(
                col, type_list=None
            ).result["observed_value"]
            if schema[col] == "object_":
                schema[col] = "object"

        dataset.expect_table_schema(schema)

    @classmethod
    def _create_table_level_expectations(cls, dataset):
        LOGGER.info("Creating table level expectations.")
        cls._build_table_schema_expectations(dataset)
        dataset.set_default_expectation_argument("catch_exceptions", True)

        value = dataset.expect_table_row_count_to_be_between(
            min_value=0, max_value=None
        ).result["observed_value"]
        dataset.expect_table_row_count_to_be_between(
            min_value=max(0, value - 1), max_value=value + 1
        )

        dataset.set_config_value("interactive_evaluation", True)

        columns = dataset.get_table_columns()

        dataset.expect_table_column_count_to_equal(len(columns))

    @classmethod
    def _creat_expectations_for_high_card_column(
        cls, dataset, column, cardinality, column_type
    ):
        # Create expectations for numeric columns
        if column_type in [ProfilerDataType.INT, ProfilerDataType.FLOAT]:
            cls._create_expectations_for_numeric_column(dataset, column)
            cls._create_additional_expectations_for_numeric_column(dataset, column)
            if cardinality == ProfilerCardinality.UNIQUE:
                dataset.expect_column_values_to_be_unique(column)

        # Create expectations for string columns
        if column_type in [ProfilerDataType.STRING, ProfilerDataType.UNKNOWN]:
            cls._create_expectations_for_string_column(dataset, column)
            if cardinality == ProfilerCardinality.UNIQUE:
                dataset.expect_column_values_to_be_unique(column)

        # Create expectations for datetime columns
        if column_type in [ProfilerDataType.DATETIME]:
            cls._create_expectations_for_datetime_column(dataset, column)

    @classmethod
    def _create_additional_expectations_for_numeric_column(cls, dataset, column):
        column_sum = dataset.expect_column_sum_to_be_between(
            column, min_value=None, max_value=None, result_format="SUMMARY"
        ).result["observed_value"]
        dataset.expect_column_sum_to_be_between(
            column, min_value=column_sum - 1, max_value=column_sum + 1
        )

        column_stdev = dataset.expect_column_stdev_to_be_between(
            column, min_value=None, max_value=None, result_format="SUMMARY"
        ).result["observed_value"]
        dataset.expect_column_stdev_to_be_between(
            column, min_value=column_stdev * 0.95, max_value=column_stdev * 1.05
        )

        partition_object = build_continuous_partition_object(dataset, column)
        dataset.expect_column_kl_divergence_to_be_less_than(
            column,
            partition_object=partition_object,
            threshold=0.6,
            catch_exceptions=True,
        )

    @classmethod
    def _get_or_create_cache(
        cls, cache_type, cache_function, dataset, column_name, cache
    ):
        column_cache_entry = cache.get(column_name)
        if not column_cache_entry:
            column_cache_entry = {}
            cache[column_name] = column_cache_entry
        column_data = column_cache_entry.get(cache_type)
        if not column_data:
            column_data = cache_function(dataset, column_name)
            column_cache_entry["cardinality"] = column_data
            dataset.set_config_value("interactive_evaluation", True)

        return column_data

    @classmethod
    def _validate_configuration(cls, dataset, configuration: Dict[str, Any]) -> None:
        included_expectations = configuration.get("included_expectations") or None
        excluded_expectations = configuration.get("excluded_expectations") or None

        if included_expectations and excluded_expectations:
            raise ProfilerError(
                "Please specify either `included_expectations` or `excluded_expectations`."
            )

        if included_expectations:
            _check_that_expectations_are_available(dataset, included_expectations)
        if excluded_expectations:
            _check_that_expectations_are_available(dataset, excluded_expectations)

    @classmethod
    def _profile(
        cls, dataset, configuration: Dict[str, Any] = None
    ) -> List[Dict[str, Any]]:
        if configuration:
            cls._validate_configuration(dataset, configuration)

        cls._create_table_level_expectations(dataset)

        columns = dataset.get_table_columns()

        meta_columns = {}
        for column in columns:
            LOGGER.info("Preparing column %s", column)

            meta_columns[column] = {"description": ""}

            column_cache = {}

            column_cardinality = cls._get_or_create_cache(
                "cardinality",
                cls._get_column_cardinality,
                dataset,
                column,
                column_cache,
            )

            column_type = cls._get_or_create_cache(
                "type", cls._get_column_type, dataset, column, column_cache
            )

            if column_cardinality in {
                ProfilerCardinality.ONE,
                ProfilerCardinality.TWO,
                ProfilerCardinality.VERY_FEW,
                ProfilerCardinality.FEW,
            }:
                cls._create_expectations_for_low_card_column(
                    dataset, column, column_cache
                )

            if column_cardinality in {
                ProfilerCardinality.MANY,
                ProfilerCardinality.VERY_MANY,
                ProfilerCardinality.UNIQUE,
            }:
                cls._creat_expectations_for_high_card_column(
                    dataset, column, column_cardinality, column_type
                )

        if configuration:
            cls._filter_expectations(dataset, configuration)

        expectation_suite = dataset.get_expectation_suite(
            suppress_warnings=True, discard_failed_expectations=False
        )
        if not expectation_suite.meta:
            expectation_suite.meta = {"columns": meta_columns, "notes": {""}}
        else:
            expectation_suite.meta["columns"] = meta_columns

        return expectation_suite

    @classmethod
    def _filter_expectations(cls, dataset, configuration: Dict[str, Any]):
        included_expectations = configuration.get("included_expectations")
        excluded_expectations = configuration.get("excluded_expectations")

        if excluded_expectations:
            dataset = _remove_table_expectations(dataset, excluded_expectations)
            dataset = _remove_column_expectations(dataset, excluded_expectations)

        if included_expectations:
            for expectation in dataset.get_expectation_suite().expectations:
                if expectation.expectation_type not in included_expectations:
                    try:
                        dataset.remove_expectation(
                            expectation_type=expectation.expectation_type,
                            expectation_kwargs=expectation.kwargs,
                            column=expectation.kwargs.get("column", None),
                            remove_multiple_matches=True,
                        )
                    except ValueError:
                        LOGGER.debug(
                            "Attempted to remove %s, which was not found.", expectation
                        )
