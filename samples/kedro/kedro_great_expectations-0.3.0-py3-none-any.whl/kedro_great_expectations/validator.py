# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""A dataset validation class to validate the DataCatalog's
datasets during pipeline and cli runs using great_expectations"""

import logging
import textwrap
from typing import Any, Dict, List, Optional, Tuple

import click
from great_expectations import DataContext
from great_expectations.data_context.types.resource_identifiers import (
    ExpectationSuiteIdentifier,
)
from log_symbols import LogSymbols

from kedro_great_expectations.ge_context import (
    UnsupportedDatasetError,
    generate,
    has_suite,
    validate,
)

__all__ = [
    "ValidationFailed",
    "ValidationSuiteNotFound",
    "ValidationConfig",
]


class ValidationConfig:
    """Validation class for pipeline and cli runs"""

    def __init__(
        self,
        *,
        ge_context: DataContext,
        dataset_name: str,
        data: Any,
        run_id: str = None,
        callback_kwargs: Dict[str, Any] = None,
        logger_name: str = None,
    ):
        """Validation class to validate data sets during
        pipeline and cli runs

        Args:
            ge_context: The Great Expectations context instance
            dataset_name: Name of a data set
            data: Loaded instance of a registered data set
            run_id: The kedro run_id
            callback_kwargs: Any arguments to pass to the validation callbacks
                when validation fails
            logger_name: Name of the logger instance, if None output
                will not be logged
        """
        self._logger_name = logger_name
        self._ge_context = ge_context
        self._run_id = run_id
        self._dataset_name = dataset_name
        self._data = data
        self._callback_kwargs = callback_kwargs or {}
        self._on_missing_suite_answer = None

    @property
    def _logger(self):
        return logging.getLogger(self._logger_name)

    def _logger_log(self, *args, level: str = "info"):
        if self._logger_name:
            getattr(self._logger, level)(*args)

    def _enabled(self, merged_config):
        enabled = merged_config["enable"]

        if not enabled:
            self._logger_log(
                "[config: %s] Validation disabled for dataset %s, skipping.",
                merged_config["group_names"],
                self._dataset_name,
            )

        return enabled

    def _on_missing_suite(self, suite_name, merged_config):
        on_missing_suite = merged_config["on_missing_suite"]

        msg = "[config: {}] Validation suite {}{} for dataset {} not found.".format(
            merged_config["group_names"],
            click.style(suite_name, bold=True, reset=False),
            click.style("", bold=False, reset=False),
            self._dataset_name,
        )

        if on_missing_suite == "ignore":
            self._logger_log("%s, ignoring.", msg, level="debug")
        elif on_missing_suite == "warn":
            self._logger_log(msg, level="warning")
        elif on_missing_suite == "raise":
            raise ValidationSuiteNotFound(msg)
        elif on_missing_suite == "ask":
            if self._on_missing_suite_answer == "N":
                self._logger_log(msg)
                return

            if self._on_missing_suite_answer is None:
                stars = "*" * 80
                msg = textwrap.fill(msg, 80)
                self._on_missing_suite_answer = click.prompt(
                    click.style(
                        "{stars}\n{msg}\n{stars}".format(stars=stars, msg=msg),
                        fg="magenta",
                    )
                    + "\nGenerate a new one? (y, n for this) or (Y, N for all datasets)",
                    type=click.Choice(["y", "n", "Y", "N"]),
                    default="n",
                    show_choices=False,
                )

            if self._on_missing_suite_answer.lower() == "y":
                generate(
                    self._dataset_name,
                    data=self._data,
                    suite_name=suite_name,
                    run_id=self._run_id,
                    ge_context=self._ge_context,
                )

    def _action(self, result, suite_name, merged_config):
        msg = "[config: {}] Validation suite {} for dataset {} ".format(
            merged_config["group_names"],
            click.style(suite_name, fg="cyan"),
            self._dataset_name,
        )
        if result["success"]:
            self._logger_log("%s%s.", msg, click.style("successful", fg="green"))
        else:
            suite_id = ExpectationSuiteIdentifier(suite_name)
            errors = _extract_errors(
                result["details"][suite_id]["validation_result"]["results"]
            )
            if merged_config["action"] == "raise":
                raise ValidationFailed(
                    msg + click.style("failed:\n", fg="red") + errors
                )
            if merged_config["action"] == "warn":
                self._logger_log(
                    "%s%s:\n%s",
                    msg,
                    click.style("failed", fg="red"),
                    errors,
                    level="warning",
                )

    def _callbacks(self, result, merged_config):
        for callback in merged_config["callbacks"]:
            self._logger_log(
                "[config: %s] Executing callback %s for dataset %s",
                merged_config["group_names"],
                callback,
                self._dataset_name,
            )
            callback(self._dataset_name, self._data, result, **self._callback_kwargs)

    def validate(
        self, *, merged_config: Dict[str, Any], suite_name: str,
    ) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """Run great expectation validation (GE)

        Args:
            merged_config: The merged validation config matching the
                specified dataset and layer name
            suite_name: Name of a specific suite you want to validate
                against

        Returns:
            Success/Failure bool, GE run results
        """
        if not self._enabled(merged_config):
            return False, None

        is_missing_suite = not has_suite(suite_name, self._ge_context)
        if is_missing_suite:
            self._on_missing_suite(suite_name, merged_config)
            return False, None

        try:
            result = validate(
                self._dataset_name,
                data=self._data,
                suite_name=suite_name,
                run_id=self._run_id,
                ge_context=self._ge_context,
            )
        except UnsupportedDatasetError as err:
            self._logger_log(str(err))
            return False, None

        self._callbacks(result, merged_config)
        self._action(result, suite_name, merged_config)

        return True, result


def _extract_errors(validations: List[Any]) -> str:
    messages = []
    for validation in validations:
        rule = validation.expectation_config.expectation_type
        rule = click.style(rule, fg="yellow")
        details = validation.expectation_config.kwargs
        if not validation.success:
            message = "[{}] Rule {} failed".format(LogSymbols.ERROR.value, rule)
            column = details.get("column")
            if column:
                column = click.style(column, fg="blue")
                message = "{} for column {}".format(message, column)
            messages.append(message)
    return "\n".join(messages)


class ValidationFailed(Exception):
    """Dataset failed validation"""


class ValidationSuiteNotFound(Exception):
    """Dataset validation suite cannot be found"""
