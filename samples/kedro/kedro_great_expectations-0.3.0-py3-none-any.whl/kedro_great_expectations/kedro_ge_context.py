# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.
"""A combination of Kedro and GE's context, uses functionality from ge_context.py"""
import warnings
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, NamedTuple, Type, Union

import great_expectations.exceptions as ge_exceptions
import kedro
import semver
from great_expectations.data_context import DataContext
from great_expectations.profile.base import DatasetProfiler
from kedro.utils import load_obj

from kedro_great_expectations import ge_context
from kedro_great_expectations.config import KedroGEConfig
from kedro_great_expectations.ge_context import GREAT_EXPECTATIONS_PATH
from kedro_great_expectations.kedro_datasets import KedroDataSets
from kedro_great_expectations.kedro_notebook_renderer import KedroNotebookRenderer
from kedro_great_expectations.transformer import ValidationConfig

KEDRO_VERSION = semver.VersionInfo.parse(kedro.__version__)

if KEDRO_VERSION.match(">=0.16.0"):
    from kedro.framework.context import load_context
else:
    from kedro.context import load_context


class KedroGEContextError(Exception):
    """Context errors"""


class KedroGEContextResult(NamedTuple):
    """KedroGEContext result object"""

    success: bool
    result: Any = None
    exception: Exception = None


# pylint: disable=broad-except
class KedroGEContext:
    """A combination of Kedro and GE's context.

    Args:
        env: The kedro environment to use.
        project_root: The root directory of the kedro project.
        dataset_filter: What filter to apply to kedro dataset names when doing any lookups.
        dataset_types: What dataset types to filter against when doing any lookups.
        locate_args: Command line input to filter down inputted datasets, passed to KedroDataSets
    """

    def __init__(
        self,
        env: str = None,
        project_root: Union[str, Path] = Path.cwd(),
        dataset_filter: str = None,
        dataset_types: List[str] = None,
        locate_args: List = None,
    ):
        self.project_root = project_root
        self._env = env
        self._dataset_filter = dataset_filter
        self._dataset_types = dataset_types
        self._locate_args = locate_args or []
        self._kedro_context = None
        self._ge_context = None
        self._kedro_datasets = None
        self._ds_names = None
        self._kedro_ge_config = None

    @property
    def kedro_context(self):
        """The Kedro context instance"""
        if self._kedro_context is None:
            self._kedro_context = load_context(self.project_root, env=self._env)
            self._kedro_ge_config = KedroGEConfig.for_interactive_mode(
                self._kedro_context
            )
        return self._kedro_context

    @property
    def kedro_ge_config(self):
        """The KedroGEConfig instance"""
        if self._kedro_ge_config is None:
            _ = self.kedro_context
        return self._kedro_ge_config

    @property
    def ge_context(self):
        """The Great Expectations context instance."""
        if self._ge_context is None:
            try:
                self._ge_context = ge_context.get_ge_context(
                    self.project_root / GREAT_EXPECTATIONS_PATH
                )
            except ge_exceptions.ConfigNotFoundError:
                raise KedroGEContextError(
                    "Great Expectations configuration cannot be found. "
                    "Try running `kedro ge init` once in your root directory."
                )
        return self._ge_context

    @property
    def kedro_datasets(self):
        """Collection of Kedro datasets from Kedro's catalog"""
        if self._kedro_datasets is None:
            self._kedro_datasets = KedroDataSets(
                self.kedro_context.catalog,
                dataset_filter=self._dataset_filter,
                dataset_types=self._dataset_types,
            )
        return self._kedro_datasets

    @property
    def datasets(self):
        """A list of Kedro datasets, filtered to match the locate args"""
        return self.kedro_datasets.locate(*self._locate_args)

    @property
    def ds_names(self):
        """The set of dataset names"""
        if self._ds_names is None:
            self._ds_names = set(ds["ds_name"] for ds in self.datasets)
        return self._ds_names

    @property
    def ds_names_with_suites(self):
        """The set of datasets that have non-empty expectation suites"""
        return set(
            ds for ds in self.ds_names if ge_context.has_suite(ds, self.ge_context)
        )

    @property
    def ds_names_without_suites(self):
        """The set of datasets that don't have expectation suites or have empty ones"""
        return set(
            ds for ds in self.ds_names if not ge_context.has_suite(ds, self.ge_context)
        )

    def initialise_ge(self):
        """Initialise the great expectations directory in the kedro project root."""
        DataContext.create(self.project_root)

    def generate(
        self,
        ds_name: str,
        empty=False,
        suite_name: str = None,
        run_id: str = None,
        overwrite_existing: bool = False,
    ) -> KedroGEContextResult:
        """Generate an expectation suite for a dataset."""
        try:
            data = self.kedro_context.catalog.load(ds_name) if not empty else None
            suite_configs = self._get_suite_configs(ds_name)
            profiler = self._get_profiler(ds_name, suite_configs)
            result = ge_context.generate(
                ds_name,
                data,
                empty,
                profiler,
                suite_name,
                run_id,
                self.ge_context,
                overwrite_existing,
            )
            return KedroGEContextResult(success=True, result=result)
        except Exception as exc:
            return KedroGEContextResult(success=False, exception=exc)

    def _get_suite_configs(self, ds_name: str) -> Dict[str, Any]:
        """Helper method to get merged configs"""
        layers = getattr(self.kedro_context.catalog, "layers", None)
        layer = layers.get(ds_name, "") if layers else ""
        suite_configs = self.kedro_ge_config.merged_configs_for(ds_name, layer)
        return suite_configs

    @staticmethod
    def _get_profiler(
        ds_name: str, suite_configs: Dict[str, Any]
    ) -> Type[DatasetProfiler]:
        """Helper method to load profiler

        Args:
            ds_name: Name of the data set
            suite_configs: Dictionary of merged configurations

        Returns:
            Profiler object
        """
        profiler_configuration = suite_configs[ds_name]["profiler"]
        return load_obj(profiler_configuration["name"])

    def profile(self, ds_name: str) -> KedroGEContextResult:
        """Profile a dataset"""
        try:
            data = self.kedro_context.catalog.load(ds_name)
            suite_configs = self._get_suite_configs(ds_name)
            profiler_configuration = suite_configs[ds_name]["profiler"]
            profiler = self._get_profiler(ds_name, suite_configs)
            result = ge_context.profile(
                ds_name, data, profiler, self.ge_context, profiler_configuration
            )
            return KedroGEContextResult(success=True, result=result)
        except Exception as exc:
            return KedroGEContextResult(success=False, exception=exc)

    @lru_cache(maxsize=1)
    def load_data(self, ds_name: str) -> Any:
        """Helper to cache loaded data in memory

            Args:
                ds_name: Name of the kedro dataset to load.

            Returns:
                The loaded data from kedro
        """
        return self.kedro_context.catalog.load(ds_name)

    def validate(
        self, ds_name: str, suite: str, run_id: str = None,
    ) -> KedroGEContextResult:
        """Validate a dataset"""
        try:
            data = self.load_data(ds_name)
            validator = ValidationConfig(
                ge_context=self.ge_context,
                run_id=run_id,
                dataset_name=ds_name,
                data=data,
            )
            suite_configs = self._get_suite_configs(ds_name)
            suite_config = suite_configs.get(suite, {})
            # CLI runs should not
            #   - raise exceptions
            #   - run callbacks
            suite_config["action"] = "warn"
            suite_config["callbacks"] = []

            _, result = validator.validate(merged_config=suite_config, suite_name=suite)
            return KedroGEContextResult(success=True, result=result)
        except Exception as exc:
            return KedroGEContextResult(success=False, exception=exc)

    def edit(self, suite_name: str):
        """Edit the suite corresponding to suite_name"""
        try:
            suite = self.ge_context.get_expectation_suite(suite_name)
        except ge_exceptions.DataContextError:
            err_msg = "Expectation suite {} not found. Try running `kedro ge generate`."
            if not suite_name.isdigit():
                raise KedroGEContextError(err_msg.format(suite_name))
            dataset_name = self.kedro_datasets.locate(suite_name)[0]["ds_name"]
            try:
                suite = self.ge_context.get_expectation_suite(dataset_name)
            except ge_exceptions.DataContextError:
                raise KedroGEContextError(err_msg.format(dataset_name))
        else:
            if suite_name.isdigit():
                warnings.warn(
                    "Using a number as a suite name conflicts with the indexing syntax "
                    "for datasets. Loaded suite with name {} but consider using "
                    "non-numeric names for your suites".format(suite_name),
                    SyntaxWarning,
                )

        nb_name = "{}.ipynb".format(suite.expectation_suite_name)
        notebook_path = (
            self.project_root
            / ge_context.GREAT_EXPECTATIONS_PATH
            / "uncommitted"
            / nb_name
        )
        KedroNotebookRenderer().render_to_disk(suite, notebook_path)

        return notebook_path
