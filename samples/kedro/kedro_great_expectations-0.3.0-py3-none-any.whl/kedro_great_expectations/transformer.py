# Copyright (c) 2016 - present
# QuantumBlack Visual Analytics Ltd (a McKinsey company).
# All rights reserved.
#
# This software framework contains the confidential and proprietary information
# of QuantumBlack, its affiliates, and its licensors. Your use of these
# materials is governed by the terms of the Agreement between your organisation
# and QuantumBlack, and any unauthorised use is forbidden. Except as otherwise
# stated in the Agreement, this software framework is for your internal use
# only and may only be shared outside your organisation with the prior written
# permission of QuantumBlack.

"""A dataset validation transformer to validate the DataCatalog's
datasets during pipeline runs using great_expectations"""

from typing import Any, Callable, Dict, Union

from kedro.io import AbstractTransformer

from kedro_great_expectations import ge_context
from kedro_great_expectations.config import KedroGEConfig
from kedro_great_expectations.validator import ValidationConfig

__all__ = [
    "ValidationTransformer",
]


class ValidationTransformer(AbstractTransformer):
    """A transformer that validates datasets during
    pipeline runs using great_expectations.
    """

    def __init__(
        self,
        config: Union[KedroGEConfig, Dict[str, Any]] = None,
        run_id: str = None,
        layers: Dict[str, str] = None,
        validation_callback_kwargs: Dict[str, Any] = None,
    ):
        """Create a ValidationTransformer, which validates datasets during
        pipeline runs using great_expectations.

        Args:
            config: The validation configuration (see
                :class:`kedro_great_expectations.config.KedroGEConfig` for details)
            run_id: The kedro run_id
            layers: A dictionary from dataset name -> layer. In kedro>=0.16 you can get this
                from `DataCatalog.layers`
            validation_callback_kwargs: Any arguments to pass to the validation callbacks
                when validation fails
        """
        config = config or {}
        self._config = KedroGEConfig(config) if isinstance(config, dict) else config
        self._ge_context = ge_context.get_ge_context()
        self._run_id = run_id
        self._layers = layers or {}
        self._callback_kwargs = validation_callback_kwargs
        self._validated = set()

    def load(self, data_set_name: str, load: Callable[[], Any]) -> Any:
        data = load()
        self._validate(data_set_name, data)
        return data

    def save(self, data_set_name: str, save: Callable[[Any], None], data: Any) -> None:
        self._validate(data_set_name, data)
        save(data)

    @property
    def config(self) -> KedroGEConfig:
        """The validation configuration applied to this transformer"""
        return self._config

    def _validate(self, dataset_name, data):
        if (
            not KedroGEConfig.TRANSFORMER_ENABLED
            or dataset_name in self._validated
            or not self.config.validation_config.get("enable", True)
        ):
            return

        validator = ValidationConfig(
            ge_context=self._ge_context,
            run_id=self._run_id,
            dataset_name=dataset_name,
            data=data,
            callback_kwargs=self._callback_kwargs,
            logger_name=self.__class__.__name__,
        )

        layer_name = self._layers.get(dataset_name, "")
        suite_configs = self.config.merged_configs_for(dataset_name, layer_name)
        for suite_name, config in suite_configs.items():
            success, _ = validator.validate(merged_config=config, suite_name=suite_name)
            if success:
                self._validated.add(dataset_name)
